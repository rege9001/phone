# LB Phone

Please read the [docs](https://docs.lbphone.com/) for a guide on how to set up the phone.
